프로테우스 회로에서 부저(Buzzer)대신에 Speaker을 이용하면 좀 더 깔끔한 소리를 출력하며 시각적으로도 나타낼 수 있음.

Microchip Studio에서 상단 탭에 Project -> (project_name) properties -> Toolchain -> AVU/GNU C Compiler -> Optimization 경로를 통해
Optimization Level 설정이 가능함. 